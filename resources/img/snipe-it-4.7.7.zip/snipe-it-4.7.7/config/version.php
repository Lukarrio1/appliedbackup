<?php
return array (
  'app_version' => 'v4.7.7',
  'full_app_version' => 'v4.7.7 - build 4160-gb8f7cd81e',
  'build_version' => '4160',
  'prerelease_version' => '',
  'hash_version' => 'gb8f7cd81e',
  'full_hash' => 'v4.7.7-41-gb8f7cd81e',
  'branch' => 'master',
);
